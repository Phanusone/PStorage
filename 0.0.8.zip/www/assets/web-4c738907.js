import{W as n}from"./index-ab8e9b7c.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
