import{W as n}from"./index.669f5f22.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
