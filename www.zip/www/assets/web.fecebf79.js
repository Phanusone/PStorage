import{W as n}from"./index.8659a5f7.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
