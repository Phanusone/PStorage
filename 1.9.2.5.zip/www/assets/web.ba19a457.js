import{b9 as n}from"./vendor.1ce48dba.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
