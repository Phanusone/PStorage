import{W as n}from"./index-244cf90a.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
